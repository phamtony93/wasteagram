import 'package:flutter/cupertino.dart';

double padding(context) {
  return MediaQuery.of(context).size.height *.05;
}