import 'dart:io';

class Entry {
  int itemCount;
  File image;
  String date;
}